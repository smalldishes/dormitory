package com.sevlet;

import com.bean.Repair;
import com.dao.RepairDao;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
@WebServlet("/DealServlet")
public class DealServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doPost(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        PrintWriter out = resp.getWriter();
        RepairDao dao=new RepairDao();
        String dorm=req.getParameter("dorm");
        String name_man=req.getParameter("name");
        String tel_man=req.getParameter("tel");
        String wx_time=req.getParameter("time");
        String state=req.getParameter("state");
        System.out.println(dorm+name_man+tel_man+wx_time+state);
        Boolean flag1=dao.insert_man(name_man,tel_man,wx_time,dorm);
        if(flag1){
            Boolean flag2=dao.change_state(dorm,name_man,state);
            if(flag2){
                out.print("<script>alert('提交成功！');window.location.href='DWXlist.jsp'</script>");
            }
        }
    }
}
