package com.sevlet;

import com.bean.Repair;
import com.dao.RepairDao;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
@WebServlet("/repairListSevlet")
public class repairListSevlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doPost(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String state=req.getParameter("condition");
        RepairDao dao=new RepairDao();
        List<Repair> list = dao.repairList(state);
        req.setAttribute("list",list);
        //请求转发到原页面
        req.getRequestDispatcher("repairList.jsp").forward(req,resp);
    }
}
