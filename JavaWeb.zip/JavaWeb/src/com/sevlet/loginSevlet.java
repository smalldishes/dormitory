package com.sevlet;

import com.bean.User;
import com.dao.UserDao;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;

@WebServlet("/loginSevlet")
public class loginSevlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doPost(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html;charset=utf-8");
        HttpSession session=req.getSession();
        PrintWriter out = resp.getWriter();
        String name = req.getParameter("username");
        String password = req.getParameter("password");
        UserDao userDao=new UserDao();
        User user=userDao.checkLogin(name,password);
        if(user!=null){
            //将用户名保存在session中
            session.setAttribute("username",name);
            String identify=user.getIdentify();
            session.setAttribute("identify",identify);
          //根据identify判断登录的用户的身份，根据不同权限进入不同主页
            if(identify.equals("普通用户")){
                resp.sendRedirect("mainStudent.jsp");
            } else if (identify.equals("维修人员")) {
                resp.sendRedirect("mainService.jsp");
            } else if (identify.equals("管理员")) {
                resp.sendRedirect("mainManager.jsp");
            } else if (identify.equals("学会")) {

            }

        }else{
            out.print("<script>alert('用户不存在!');window.location.href='login.jsp'</script>");
        }

    }
}
