package com.sevlet;

import com.dao.RepairDao;
import com.dao.UserDao;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;


@WebServlet("/RepairSevlet")
public class RepairSevlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doPost(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        PrintWriter out = resp.getWriter();
        String name_stu=req.getParameter("name");
        String dorm=req.getParameter("dorm");
        String goods=req.getParameter("goods");
        String reason=req.getParameter("reason");
        String tel_stu=req.getParameter("tel");
        String sq_time=req.getParameter("time");
        String state=req.getParameter("state");
        RepairDao dao=new RepairDao();
        Boolean flag=dao.insert(name_stu,dorm,goods,reason,tel_stu,sq_time,state);
        if(flag){
            out.print("<script>alert('申请成功!');window.location.href='PersonInfo.jsp'</script>");
        }

    }
}
