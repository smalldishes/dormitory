package com.sevlet;

import com.bean.Repair;
import com.dao.RepairDao;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/repairHisStuSevlet")
public class repairHisStuSevlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doPost(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String dorm=req.getParameter("value");
        String state=req.getParameter("condition");
        System.out.println(dorm+state);
        RepairDao dao=new RepairDao();
        List<Repair> list = dao.repairList_stu(dorm,state);
        req.setAttribute("list",list);
        //请求转发到原页面
        req.getRequestDispatcher("repairhistory_stu.jsp").forward(req,resp);
    }
}
