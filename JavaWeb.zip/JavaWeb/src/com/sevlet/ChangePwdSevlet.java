package com.sevlet;

import com.dao.UserDao;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Objects;

@WebServlet("/ChangePwdSevlet")
public class ChangePwdSevlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doPost(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html;charset=utf-8");
        PrintWriter out = resp.getWriter();
        String oldPwd = req.getParameter("OldPwd");
        String newPwd = req.getParameter("NewPwd");
        String RepPwd=req.getParameter("RepPwd");
        UserDao userDao=new UserDao();
        Boolean flag=userDao.Changepwd(oldPwd,newPwd);
        System.out.println("flag="+flag);
        if(flag && Objects.equals(newPwd, RepPwd)){
            out.print("<script>alert('修改成功！');window.location.href='PersonInfo.jsp'</script>");
        }else if(!flag){
            out.print("<script>alert('原始密码输入错误，请重新输入！');window.location.href='ChangePwd.jsp'</script>");
        }else if(!Objects.equals(newPwd, RepPwd)){
            out.print("<script>alert('两次密码输入不一致，请重新输入！');window.location.href='ChangePwd.jsp'</script>");
        }
    }
}
