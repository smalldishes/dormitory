package com.bean;

public class User {
    private String name;
    private String password;
    private String identify;

    public User(String name, String password, String identify) {
        this.name = name;
        this.password = password;
        this.identify = identify;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getIdentify() {
        return identify;
    }

    public void setIdentify(String identify) {
        this.identify = identify;
    }
}
