package com.bean;



public class Repair {
    private String name_stu;
    private String dorm;
    private String goods;
    private String reason;
    private String tel_stu;
    private String sq_time;
    private String name_man;
    private String tel_man;
    private String wx_time;
    private String state;

    public Repair(String name_stu,String dorm,String goods,String reason,String tel_stu,String sq_time,String state) {
        this.name_stu=name_stu;
        this.dorm = dorm;
        this.goods=goods;
        this.reason=reason;
        this.tel_stu=tel_stu;
        this.sq_time=sq_time;
        this.state=state;
    }

    public Repair(String name_man, String tel_man, String wx_time, String state) {
        this.name_man = name_man;
        this.tel_man = tel_man;
        this.wx_time = wx_time;
        this.state = state;
    }

    public Repair(String name_stu, String dorm, String goods, String reason,
                  String tel_stu, String sq_time, String name_man, String tel_man, String wx_time, String state) {
        this.name_stu = name_stu;
        this.dorm = dorm;
        this.goods = goods;
        this.reason = reason;
        this.tel_stu = tel_stu;
        this.sq_time = sq_time;
        this.name_man = name_man;
        this.tel_man = tel_man;
        this.wx_time = wx_time;
        this.state = state;
    }

    public String getName_stu() {
        return name_stu;
    }

    public void setName_stu(String name_stu) {
        this.name_stu = name_stu;
    }

    public String getDorm() {
        return dorm;
    }

    public void setDorm(String dorm) {
        this.dorm = dorm;
    }

    public String getGoods() {
        return goods;
    }

    public void setGoods(String goods) {
        this.goods = goods;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getTel_stu() {
        return tel_stu;
    }

    public void setTel_stu(String tel_stu) {
        this.tel_stu = tel_stu;
    }

    public String getSq_time() {
        return sq_time;
    }

    public void setSq_time(String sq_time) {
        this.sq_time = sq_time;
    }

    public String getName_man() {
        return name_man;
    }

    public void setName_man(String name_man) {
        this.name_man = name_man;
    }

    public String getTel_man() {
        return tel_man;
    }

    public void setTel_man(String tel_man) {
        this.tel_man = tel_man;
    }

    public String getWx_time() {
        return wx_time;
    }

    public void setWx_time(String wx_time) {
        this.wx_time = wx_time;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }
}
