package com.bean;

public class Student {
    private String name;//姓名
    private String id;//学号
    private String sex;//性别
    private String nation;//民族
    private String place;//籍贯
    private String bj;//班级
    private String dorm;//宿舍号
    private String tel;//联系电话
    private String faculty;//学院
    private String bed;//床位

    public Student(String name, String id, String sex, String nation, String place, String bj,
                   String dorm, String tel,String faculty,String bed) {
        this.name = name;
        this.id = id;
        this.sex = sex;
        this.nation = nation;
        this.place = place;
        this.bj = bj;
        this.dorm = dorm;
        this.tel = tel;
        this.faculty=faculty;
        this.bed=bed;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getNation() {
        return nation;
    }

    public void setNation(String nation) {
        this.nation = nation;
    }

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }

    public String getBj() {
        return bj;
    }

    public void setBj(String bj) {
        this.bj = bj;
    }

    public String getDorm() {
        return dorm;
    }

    public void setDorm(String dorm) {
        this.dorm = dorm;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getFaculty() {
        return faculty;
    }

    public void setFaculty(String faculty) {
        this.faculty = faculty;
    }

    public String getBed() {
        return bed;
    }

    public void setBed(String bed) {
        this.bed = bed;
    }
}
