package com.bean;

public class Dorm {
    private String dorm;
    private String buildings;
    private String floor;
    private String room;

    public Dorm(String dorm, String buildings, String floor, String room) {
        this.dorm = dorm;
        this.buildings = buildings;
        this.floor = floor;
        this.room = room;
    }

    public String getDorm() {
        return dorm;
    }

    public void setDorm(String dorm) {
        this.dorm = dorm;
    }

    public String getBuildings() {
        return buildings;
    }

    public void setBuildings(String buildings) {
        this.buildings = buildings;
    }

    public String getFloor() {
        return floor;
    }

    public void setFloor(String floor) {
        this.floor = floor;
    }

    public String getRoom() {
        return room;
    }

    public void setRoom(String room) {
        this.room = room;
    }
}
