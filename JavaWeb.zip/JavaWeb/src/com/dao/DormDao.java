package com.dao;

import com.bean.Student;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DormDao {
    Connection conn=null;
    PreparedStatement pst=null;
    ResultSet rs=null;

    public List DormList(String buildings,String floor){
        List list=new ArrayList<>();
        try {
            conn= JDBC.getConnection();
            String sql="select name,buildings,floor,students.dorm,bed,tel from " +
                    "students,dorms where buildings=? and floor=? and students.dorm=dorms.dorm";
            pst=conn.prepareStatement(sql);
            pst.setString(1,buildings);
            pst.setString(2,floor);
            rs=pst.executeQuery();
            while(rs.next()){
                String name=rs.getString("name");
                String building=rs.getString("buildings");
                String floor1=rs.getString("floor");
                String dorm=rs.getString("dorm");
                String bed=rs.getString("bed");
                String tel=rs.getString("tel");
                Map<String,String> item=new HashMap<>();
                item.put("name",name);
                item.put("building",building);
                item.put("floor",floor1);
                item.put("dorm",dorm);
                item.put("bed",bed);
                item.put("tel",tel);
               list.add(item);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            JDBC.closeAll(rs,pst,conn);
        }
        return list;
    }

    public List DormList(String dorm){
        List list=new ArrayList<>();
        try {
            conn= JDBC.getConnection();
            String sql="select name,id,faculty,students.dorm,bed,tel from " +
                    "students,dorms where dorm=? and students.dorm=dorms.dorm";
            pst=conn.prepareStatement(sql);
            pst.setString(1,dorm);
            rs=pst.executeQuery();
            while(rs.next()){
                String name=rs.getString("name");
                String id=rs.getString("id");
                String faculty=rs.getString("faculty");
                String dorm1=rs.getString("dorm");
                String bed=rs.getString("bed");
                String tel=rs.getString("tel");
                Map<String,String> item=new HashMap<>();
                item.put("name",name);
                item.put("building",id);
                item.put("floor",faculty);
                item.put("dorm",dorm1);
                item.put("bed",bed);
                item.put("tel",tel);
                list.add(item);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            JDBC.closeAll(rs,pst,conn);
        }
        return list;
    }
}
