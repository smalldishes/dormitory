package com.dao;

import com.bean.Student;
import com.bean.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class StudentDao {
    Connection conn=null;
    PreparedStatement pst=null;
    ResultSet rs=null;
    Student stu=null;
    //根据姓名查找学生
    public Student findStudent(String name){
        try {
            conn= JDBC.getConnection();
            String sql="select * from students where name=?";
            pst=conn.prepareStatement(sql);
            pst.setString(1,name);
            rs=pst.executeQuery();
            while(rs.next()){
              String username=rs.getString("name");
              String id=rs.getString("id");
              String sex=rs.getString("sex");
              String nation=rs.getString("nation");
              String place=rs.getString("place");
              String bj=rs.getString("bj");
              String dorm=rs.getString("dorm");
              String tel=rs.getString("tel");
              String faculty=rs.getString("faculty");
              String bed=rs.getString("bed");
              stu=new Student(username,id,sex,nation,place,bj,dorm,tel,faculty,bed);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            JDBC.closeAll(rs,pst,conn);
        }
        return stu;
    }

    //根据条件查找学生列表
    public List<Student> findStudentList(String faculty,String sex){
        List<Student> list=new ArrayList<Student>();
        try {
            conn= JDBC.getConnection();
            String sql="select * from students where faculty=? and sex=?";
            String sql1="select * from students";
            if(faculty.equals("全部")){
                pst=conn.prepareStatement(sql1);

            }else{
                pst=conn.prepareStatement(sql);
                pst.setString(1,faculty);
                pst.setString(2,sex);
            }
            rs=pst.executeQuery();
            while(rs.next()){
                String username=rs.getString("name");
                String id=rs.getString("id");
                String sex1=rs.getString("sex");
                String nation=rs.getString("nation");
                String place=rs.getString("place");
                String bj=rs.getString("bj");
                String dorm=rs.getString("dorm");
                String tel=rs.getString("tel");
                String faculty1=rs.getString("faculty");
                String bed=rs.getString("bed");
                stu=new Student(username,id,sex1,nation,place,bj,dorm,tel,faculty1,bed);
                list.add(stu);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            JDBC.closeAll(rs,pst,conn);
        }
        return list;
    }
}
