package com.dao;

import com.bean.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserDao {
   List<User> list=new ArrayList<User>();
    Connection conn=null;
    PreparedStatement pst=null;
    ResultSet rs=null;
    //根据姓名查找用户
    public List<User> findUser(String name){
        try {
            conn= JDBC.getConnection();
            String sql="select * from users where name=?";
           pst=conn.prepareStatement(sql);
            pst.setString(1,name);
            rs=pst.executeQuery();
            while(rs.next()){
                String username=rs.getString("name");
                String password=rs.getString("password");
                String identify=rs.getString("identify");
                User user=new User(username,password,identify);
                list.add(user);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            JDBC.closeAll(rs,pst,conn);
        }
        return list;
    }

    //判断用户登录是否成功
    public User checkLogin(String name,String password){
       List<User> userList=findUser(name);
       //名字可能重复，进而对比密码找出该用户
        if(userList!=null){
           for(int i=0;i<userList.size();i++){
               User user=userList.get(i);
               if(user.getPassword().equals(password)){
                   return user;
               }
           }
        }
        return null;
    }

    //修改用户密码
    public boolean Changepwd(String oldPwd,String newPwd){
        int result=0;
        try {
            conn= JDBC.getConnection();
            String sql="update users set password=? where password=?";
            pst=conn.prepareStatement(sql);
            pst.setString(1,newPwd);
            pst.setString(2,oldPwd);
            result=pst.executeUpdate();
            System.out.println("result="+result);
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            JDBC.closeAll(rs,pst,conn);
        }
        if(result>0){
            return true;
        }
        return false;
    }


}
