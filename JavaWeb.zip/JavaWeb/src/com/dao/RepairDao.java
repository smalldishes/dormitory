package com.dao;

import com.bean.Repair;
import com.bean.Student;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


public class RepairDao {
    //学生申请维修信息加入数据库
    public boolean insert(String name, String dorm, String goods, String reason, String tel, String time,String state){
        Connection conn=null;
        PreparedStatement pst=null;
        ResultSet rs=null;
        int executeUpdate=0;
        try {
            conn= JDBC.getConnection();
            String sql="insert into repair(name_stu,dorm,goods,reason,tel_stu,sq_time,state)" +
                    " values (?,?,?,?,?,?,?)";
            pst=conn.prepareStatement(sql);
            pst.setString(1,name);
            pst.setString(2,dorm);
            pst.setString(3,goods);
            pst.setString(4,reason);
            pst.setString(5,tel);
            pst.setString(6,time);
            pst.setString(7,state);
            System.out.println(name+dorm+goods+reason+tel+time+state);
            System.out.println("1111111111");
           executeUpdate=pst.executeUpdate();
            System.out.println("222222222");
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            JDBC.closeAll(rs,pst,conn);
        }
        if(executeUpdate>0){
            return true;
        }
        return false;
    }

    //维修人员信息录入数据库
    public boolean insert_man(String name,  String tel, String time,String dorm){
        Connection conn=null;
        PreparedStatement pst=null;
        ResultSet rs=null;
        int result=0;
        try {
            conn= JDBC.getConnection();
            String sql1="update repair set name_man=?,tel_man=?,wx_time=? where dorm=?";
            pst=conn.prepareStatement(sql1);
            pst.setString(1,name);
            pst.setString(2,tel);
            pst.setString(3,time);
            pst.setString(4,dorm);
            result=pst.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            JDBC.closeAll(rs,pst,conn);
        }
        if(result>0){
            return true;
        }
        return false;
    }
    //维修人员查看需要维修的信息列表，根据状态判定
    public List<Repair> DWXlist(){
        Connection conn=null;
        PreparedStatement pst=null;
        ResultSet rs=null;
       List<Repair> list=new ArrayList<Repair>();
        try {
            conn= JDBC.getConnection();
            String sql="select name_stu,dorm,goods,tel_stu,sq_time,reason,state from repair where state='待处理'";
            pst=conn.prepareStatement(sql);
            rs=pst.executeQuery();
            while(rs.next()){
                String name_stu=rs.getString("name_stu");
                String dorm=rs.getString("dorm");
                String goods=rs.getString("goods");
                String tel_stu=rs.getString("tel_stu");
                String sq_time=rs.getString("sq_time");
                String reason=rs.getString("reason");
                String state=rs.getString("state");
                Repair repair1=new Repair(name_stu,dorm,goods,reason,tel_stu,sq_time,state);
                list.add(repair1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            JDBC.closeAll(rs,pst,conn);
        }
        return list;
    }


    //修改状态
    public boolean change_state(String dorm,String name,String state){
        Connection conn=null;
        PreparedStatement pst=null;
        ResultSet rs=null;
        int result=0;
        try {
            conn= JDBC.getConnection();
            String sql1="update repair set state=? where dorm=? and name_man=?";
            pst=conn.prepareStatement(sql1);
            pst.setString(1,state);
            pst.setString(2,dorm);
            pst.setString(3,name);
            result=pst.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            JDBC.closeAll(rs,pst,conn);
        }
        if(result>0){
            return true;
        }
        return false;
    }
    //维修员查看自己的维修历史
    public List<Repair> manHistory(String name){
            Connection conn=null;
            PreparedStatement pst=null;
            ResultSet rs=null;
            List<Repair> list=new ArrayList<Repair>();
            try {
                conn= JDBC.getConnection();
                String sql="select * from repair where name_man=?";
                pst=conn.prepareStatement(sql);
                pst.setString(1,name);
                rs=pst.executeQuery();
                while(rs.next()){
                    String name_stu=rs.getString("name_stu");
                    String dorm=rs.getString("dorm");
                    String goods=rs.getString("goods");
                    String tel_stu=rs.getString("tel_stu");
                    String sq_time=rs.getString("sq_time");
                    String reason=rs.getString("reason");
                    String state=rs.getString("state");
                    String wx_time=rs.getString("wx_time");
                    Repair repair1=new Repair(name_stu,dorm,goods,reason,tel_stu,sq_time,null,null,wx_time,state);
                    list.add(repair1);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }finally {
                JDBC.closeAll(rs,pst,conn);
            }
            return list;
    }
    //管理员查看全部维修信息---根据状态
    public List<Repair> repairList(String state){
        Connection conn=null;
        PreparedStatement pst=null;
        ResultSet rs=null;
        List<Repair> list=new ArrayList<Repair>();
        try {
            conn= JDBC.getConnection();
            String sql="select * from repair where state=?";
            String sql1="select * from repair";
            if(state.equals("全部")){
                pst=conn.prepareStatement(sql1);
            }else{
                pst=conn.prepareStatement(sql);
                pst.setString(1,state);
            }
            rs=pst.executeQuery();
            while(rs.next()){
                String name_stu=rs.getString("name_stu");
                String dorm=rs.getString("dorm");
                String goods=rs.getString("goods");
                String tel_stu=rs.getString("tel_stu");
                String sq_time=rs.getString("sq_time");
                String reason=rs.getString("reason");
                String state1=rs.getString("state");
                String wx_time=rs.getString("wx_time");
                String name_man=rs.getString("name_man");
                String tel_man=rs.getString("tel_man");
                Repair repair1=new Repair(name_stu,dorm,goods,reason,tel_stu,sq_time,name_man,tel_man,wx_time,state);
                list.add(repair1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            JDBC.closeAll(rs,pst,conn);
        }
        return list;
    }
    //学生查看维修信息---根据宿舍号
    public List<Repair> repairList_stu(String dorm,String state){
        Connection conn=null;
        PreparedStatement pst=null;
        ResultSet rs=null;
        List<Repair> list=new ArrayList<Repair>();
        try {
            conn= JDBC.getConnection();
            String sql="select name_stu,dorm,goods,tel_stu,sq_time,reason,state" +
                    " from repair where dorm=? and state=?";
            String sql1="select name_stu,dorm,goods,tel_stu,sq_time,reason,state" +
                    " from repair where dorm=?";
            if(state.equals("全部")){
                pst=conn.prepareStatement(sql1);
                pst.setString(1,dorm);
            }else{
                pst=conn.prepareStatement(sql);
                pst.setString(1,dorm);
                pst.setString(2,state);
            }
            rs=pst.executeQuery();
            while(rs.next()){
                String name_stu=rs.getString("name_stu");
                String dorm1=rs.getString("dorm");
                String goods=rs.getString("goods");
                String tel_stu=rs.getString("tel_stu");
                String sq_time=rs.getString("sq_time");
                String reason=rs.getString("reason");
                String state1=rs.getString("state");
                Repair repair1=new Repair(name_stu,dorm1,goods,reason,tel_stu,sq_time,state);
                list.add(repair1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            JDBC.closeAll(rs,pst,conn);
        }
        return list;
    }


}
