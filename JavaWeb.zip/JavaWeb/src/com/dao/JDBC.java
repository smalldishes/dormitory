package com.dao;

import java.sql.*;

public class JDBC {
    private static Connection conn=null;
    private static PreparedStatement preparedStatement=null;
    private  static ResultSet rs=null;
    //注册驱动
    static {
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }

    }
    public static Connection getConnection(){
        try {
            conn= DriverManager.getConnection
                    ("JDBC:mysql://localhost:3306/dormitory","root","123456");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return conn;
    }
    public static void closeAll(ResultSet rs,PreparedStatement preparedStatement,Connection conn){
        if(rs!=null){
            try {
                rs.close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
        if(preparedStatement!=null){
            try {
                preparedStatement.close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
        if(conn!=null){
            try {
                conn.close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
    }

}
